This library has been removed from PMDK.
