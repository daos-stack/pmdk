This tool has been removed from PMDK.
