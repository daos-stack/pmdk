This library has been removed from PMDK.
**Librpmem** library has been removed from PMDK repository. If you are interested in a remote persistent
memory support please look at new [rpma](https://github.com/pmem/rpma).
