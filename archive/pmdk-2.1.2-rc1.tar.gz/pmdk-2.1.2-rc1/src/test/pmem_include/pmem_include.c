// SPDX-License-Identifier: BSD-3-Clause
/* Copyright 2016-2019, Intel Corporation */

/*
 * pmem_include.c -- include test for libpmem
 *
 * this is only a compilation test - do not run this program
 */

#include <libpmem.h>

int
main(int argc, char *argv[])
{
	return 0;
}
