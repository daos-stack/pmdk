# SPDX-License-Identifier: BSD-3-Clause
# Copyright 2018, Intel Corporation


class InconsistentFileException(Exception):
    pass


class NotSupportedOperationException(Exception):
    pass
